package com.example.epica3.Controller;

import com.example.epica3.DTO.LoginRequest;
import com.example.epica3.DTO.LoginResponse;
import com.example.epica3.Model.UsuariosModel;
import com.example.epica3.Service.IUsuariosService;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private IUsuariosService usuariosService;

    @PostMapping("/login")
public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
    LoginResponse loginResponse = usuariosService.verificarCredenciales(loginRequest);

    if (loginResponse.isAutenticado()) {
        return ResponseEntity.ok(loginResponse);
    } else {
        Map<String, String> errorResponse = new HashMap<>();
        errorResponse.put("error", loginResponse.getMensaje());
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(errorResponse);
    }
}

    

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody UsuariosModel newUser) {
        try {
            usuariosService.registerUser(newUser);
            Map<String, String> response = new HashMap<>();
            response.put("message", "Usuario registrado exitosamente.");
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (IllegalArgumentException e) {
            Map<String, String> response = new HashMap<>();
            response.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        } catch (Exception e) {
            Map<String, String> response = new HashMap<>();
            response.put("error", "Error al registrar el usuario.");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
}
