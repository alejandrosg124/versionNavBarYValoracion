package com.example.epica3.Service;

import com.example.epica3.DTO.LoginRequest;
import com.example.epica3.DTO.LoginResponse;
import com.example.epica3.Model.Credenciales;
import com.example.epica3.Model.UsuariosModel;
import com.example.epica3.Repository.UsuariosRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UsuariosServiceImpl implements IUsuariosService {

    @Autowired
    private UsuariosRepository usuariosRepository;

    @Override
public LoginResponse verificarCredenciales(LoginRequest loginRequest) {
    String identificador = loginRequest.getIdentificador();
    String contraseña = loginRequest.getContraseña();

    Optional<UsuariosModel> usuarioOpt = usuariosRepository.findByNombreUsuario(identificador);

    if (!usuarioOpt.isPresent()) {
        usuarioOpt = usuariosRepository.findByEmail(identificador);
    }

    if (usuarioOpt.isPresent()) {
        UsuariosModel usuarioEncontrado = usuarioOpt.get();
        String contraseñaValida = usuarioEncontrado.getContraseña();

        if (contraseñaValida != null && contraseñaValida.equals(contraseña)) {
            return new LoginResponse(
                true, 
                "Login exitoso", 
                usuarioEncontrado.getNombre(),
                usuarioEncontrado.getEmail(),
                usuarioEncontrado.getNombreUsuario(),
                usuarioEncontrado.getPreguntaSeguridad(),
                usuarioEncontrado.getRespuestaSeguridad(),
                usuarioEncontrado.getRol(),
                usuarioEncontrado.getTelefono(),
                usuarioEncontrado.getDireccion(),
                usuarioEncontrado.getFechaNacimiento()
            );
        } else {
            return new LoginResponse(false, "Contraseña incorrecta", null, null, null, null, null, null, null, null, null);
        }
    }

    // Si no se encuentra el usuario
    return new LoginResponse(false, "Correo o nombre de usuario no registrado", null, null, null, null, null, null, null, null, null);
}


    @Override
    public UsuariosModel registerUser(UsuariosModel newUser) {
        // Validar si el nombre de usuario o email ya existen
        if (usuariosRepository.findByNombreUsuario(newUser.getNombreUsuario()).isPresent()) {
            throw new IllegalArgumentException("El nombre de usuario ya está en uso.");
        }
        if (usuariosRepository.findByEmail(newUser.getEmail()).isPresent()) {
            throw new IllegalArgumentException("El correo electrónico ya está en uso.");
        }
    
        // Crear un objeto de Credenciales y asignar la contraseña y el estado
        Credenciales credenciales = new Credenciales();
        credenciales.setContraseña(newUser.getContraseña()); // Asigna la contraseña desde el campo temporal
        credenciales.setEstado(true);
    
        // Añadir las credenciales al historial de contraseñas
        newUser.getHistorialContraseñas().add(credenciales);
    
        // Establecer el rol por defecto como 'USER' si no se especifica
        if (newUser.getRol() == null) {
            newUser.setRol("USER");
        }
    
        // Guardar el usuario en la base de datos con todos los campos
        return usuariosRepository.save(newUser);
    }

    @Override
    public boolean existsByNombreUsuario(String nombreUsuario) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'existsByNombreUsuario'");
    }

    @Override
    public boolean existsByEmail(String email) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'existsByEmail'");
    }

    @Override
    public LoginResponse login(String nombreUsuario, String contraseña) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'login'");
    }
    
    
}

