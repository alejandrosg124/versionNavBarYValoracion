package com.example.epica3.Service;

public interface ICategoriasService {
    
}
