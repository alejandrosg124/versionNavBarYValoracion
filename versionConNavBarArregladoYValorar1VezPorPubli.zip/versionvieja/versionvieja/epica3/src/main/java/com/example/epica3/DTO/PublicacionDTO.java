package com.example.epica3.DTO;

import java.util.Date;
import java.util.List;
import com.example.epica3.Model.Autores;

public class PublicacionDTO {
    private String titulo;
    private String descripcion;
    private Date fechaPublicacion;
    private String visibilidad;
    private List<Autores> autores;
    private String archivoBase64; // El archivo PDF en formato Base64

    public PublicacionDTO(String titulo, String descripcion, Date fechaPublicacion, String visibilidad, List<Autores> autores, String archivoBase64) {
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.fechaPublicacion = fechaPublicacion;
        this.visibilidad = visibilidad;
        this.autores = autores;
        this.archivoBase64 = archivoBase64;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getFechaPublicacion() {
        return fechaPublicacion;
    }

    public void setFechaPublicacion(Date fechaPublicacion) {
        this.fechaPublicacion = fechaPublicacion;
    }

    public String getVisibilidad() {
        return visibilidad;
    }

    public void setVisibilidad(String visibilidad) {
        this.visibilidad = visibilidad;
    }

    public List<Autores> getAutores() {
        return autores;
    }

    public void setAutores(List<Autores> autores) {
        this.autores = autores;
    }

    public String getArchivoBase64() {
        return archivoBase64;
    }

    public void setArchivoBase64(String archivoBase64) {
        this.archivoBase64 = archivoBase64;
    }

    // Getters y Setters
}
