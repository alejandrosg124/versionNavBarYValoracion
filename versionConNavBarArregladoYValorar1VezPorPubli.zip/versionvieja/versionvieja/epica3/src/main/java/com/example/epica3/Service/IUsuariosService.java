package com.example.epica3.Service;

import com.example.epica3.DTO.LoginRequest;
import com.example.epica3.DTO.LoginResponse;
import com.example.epica3.Model.UsuariosModel;

public interface IUsuariosService {
    LoginResponse login(String nombreUsuario, String contraseña);
    LoginResponse verificarCredenciales(LoginRequest loginRequest);

    // Nuevo método para registrar un usuario
    UsuariosModel registerUser(UsuariosModel newUser);

    boolean existsByNombreUsuario(String nombreUsuario);

    boolean existsByEmail(String email);
}