package com.example.epica3.Service;

import org.springframework.stereotype.Service;

@Service
public class CategoriasServiceImp implements ICategoriasService{
    
}
