package com.example.epica3.Config;

public enum RoleEnum {
    USER,   // Rol de usuario normal
    ADMIN   // Rol de administrador
}