import React, { useState, useEffect } from 'react';
import axios from 'axios';
import styles from './DocumentCatalog.module.css';
import PublicationList from './PublicationList';

const API_URL = 'http://localhost:8080/publicaciones/listarFront';

const DocumentCatalog = () => {
    const [publications, setPublications] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        const fetchPublications = async () => {
            setLoading(true); // Asegúrate de que el estado de carga se establece en true al inicio de la solicitud
            setError(null); // Restablece el estado de error antes de la solicitud
            try {
                const response = await axios.get(API_URL);
                setPublications(response.data);
            } catch (err) {
                console.error('Error en la solicitud:', err); // Muestra el error completo en la consola
                setError(`Error en la carga de publicaciones: ${err.response ? err.response.statusText : err.message}`);
            } finally {
                setLoading(false);
            }
        };

        fetchPublications();
    }, []);

    // Filtrado de publicaciones
    const filteredPublications = publications.filter(pub =>
        pub.titulo.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <div className={styles.catalogContainer}>
            <h2 className={styles.catalogTitle}>
                Catálogo de <br />
                <b>Publicaciones</b>
            </h2>
            <div className={styles.searchBar}>
                <input
                    type="text"
                    placeholder="Buscar publicaciones..."
                    className={styles.searchInput}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                />
            </div>
            <div className={styles.largeBox}>
                {loading && <div>Cargando...</div>}
                {error && <div style={{ color: 'red' }}>{error}</div>}
                {!loading && !error && filteredPublications.length === 0 && (
                    <div>No hay publicaciones disponibles.</div>
                )}
                {!loading && !error && filteredPublications.length > 0 && (
                    <PublicationList publications={filteredPublications} />
                )}
            </div>
        </div>
    );
};

export default DocumentCatalog;