import React from 'react';
import { useNavigate } from 'react-router-dom';
import styles from './PublicationList.module.css';
import '@fortawesome/fontawesome-free/css/all.min.css';

const PublicationList = ({ publications }) => {
    const navigate = useNavigate();

    const handlePublicationClick = (publication) => {
        if (publication.visibilidad === 'privado') {
            navigate('/login'); // Redirige al login si es privado
        } else if (publication.visibilidad === 'publico') {
            // Navega a la página de detalles con el ID de la publicación
            navigate(`/publicaciones/${publication._id}`);
        }
    };

    return (
        <div className={styles.publicationList}>
            {publications.map((publication, index) => (
                <div
                    key={index}
                    className={styles.publicationCard}
                    onClick={() => handlePublicationClick(publication)}
                >
                    <div className={styles.publicationThumbnail}>
                        <img
                            src={publication.imagenUrl} // Usamos imagenUrl proporcionada por el backend
                            alt={publication.titulo}
                            className={styles.thumbnailImage}
                        />
                    </div>
                    <div className={styles.publicationDetails}>
                        <h3>{publication.titulo}</h3>
                        <p>{publication.descripcion}</p>
                        <p><strong>Autor(es):</strong> {publication.autores.map(autor => autor.nombre).join(', ')}</p>
                        <p><strong>Fecha:</strong> {new Date(publication.fechaPublicacion).toLocaleDateString()}</p>
                        <div className={styles.visibilityIcon}>
                            {publication.visibilidad === 'privado' ? (
                                <i className="fas fa-lock" title="Privado"></i> // Ícono de candado
                            ) : (
                                <i className="fas fa-globe" title="Público"></i> // Ícono de mundo
                            )}
                        </div>
                    </div>
                </div>
            ))}
        </div>
    );
};

export default PublicationList;
