import React, { useState } from 'react';
import styles from "./EditarPublicacion.module.css";
import DocumentoService from '../Service/DocumentoService';

const EditarPublicacion = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [publicacionId, setPublicacionId] = useState('');
  const [publicacion, setPublicacion] = useState(null);
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const openModal = () => {
    setIsModalOpen(true);
    setError(null);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setPublicacionId('');
    setPublicacion(null);
    setError(null);
  };

  const handleInputChange = (event) => {
    setPublicacionId(event.target.value);
  };

  const validarPublicacion = async (event) => {
    event.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      const publicacionData = await DocumentoService.getPublicacion(publicacionId);
      setPublicacion(publicacionData);
      setIsLoading(false);
    } catch (error) {
      console.error('Error al validar la publicación:', error);
      setError('No se encontró la publicación con el ID proporcionado.');
      setIsLoading(false);
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    setIsLoading(true);
    setError(null);

    try {
      const publicacionActualizada = await DocumentoService.actualizarPublicacion(publicacionId, publicacion);
      console.log('Publicación actualizada correctamente:', publicacionActualizada);
      closeModal();
    } catch (error) {
      console.error('Error al actualizar la publicación:', error);
      setError('Ocurrió un error al actualizar la publicación. Por favor, inténtalo de nuevo.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={styles.editarPublicacion}>
      <div className={styles.titleContainer}>
        <p>Editar <br /><b>Publicación</b></p>
      </div>
      <button onClick={openModal} className={styles.openModalButton}>Editar publicación</button>

      {isModalOpen && (
        <div className={`${styles.modalOverlay} ${isModalOpen ? styles.open : ''}`}>
          <div className={styles.modalContent}>
            <button onClick={closeModal} className={styles.closeModalButton}>X</button>
            
            <div className={styles.titleInsideContainer}>
              <p>Editar <br /><b>Publicación</b></p>
            </div>

            {!publicacion ? (
              <form onSubmit={validarPublicacion}>
                <label htmlFor="publicacionId">ID de la Publicación:</label>
                <input
                  type="text"
                  id="publicacionId"
                  value={publicacionId}
                  onChange={handleInputChange}
                  required
                />
                <button type="submit" disabled={isLoading}>
                  {isLoading ? 'Validando...' : 'Validar Publicación'}
                </button>
              </form>
            ) : (
              <form onSubmit={handleSubmit}>
                {/* Aquí irían los campos para editar la publicación */}
                <label htmlFor="nombre">Título:</label>
                <input
                  type="text"
                  id="titulo"
                  value={publicacion.titulo}
                  onChange={(e) => setPublicacion({ ...publicacion, titulo: e.target.value })}
                  required
                />
                {/* ... */}
                <button type="submit" disabled={isLoading}>
                  {isLoading ? 'Actualizando...' : 'Actualizar Publicación'}
                </button>
              </form>
            )}

            {error && (
              <p style={{ color: 'red' }}>{error}</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default EditarPublicacion;