import React, { useState } from 'react';
import styles from "./CrearPublicacion.module.css";
import DocumentoService from '../Service/DocumentoService';

const CrearPublicacion = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [publicacion, setPublicacion] = useState({
    nombre: '',
    descripcion: '',
    autores: [''],
    visibilidad: '',
    categorias: [''],
    fechaPublicacion: ''
  });

  const openModal = () => {
    setIsModalOpen(true);
    setError(null);
    setSuccess(false);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setError(null);
    setSuccess(false);
  };

  const handleInputChange = (event) => {
    const { name, value } = event.target;
    setPublicacion({ ...publicacion, [name]: value });
  };

  const handleAutoresChange = (event, index) => {
    const newAutores = [...publicacion.autores];
    newAutores[index] = event.target.value;
    setPublicacion({ ...publicacion, autores: newAutores });
  };

  const handleCategoriasChange = (event, index) => {
    const newCategorias = [...publicacion.categorias];
    newCategorias[index] = event.target.value;
    setPublicacion({ ...publicacion, categorias: newCategorias });
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const documentoCreado = await DocumentoService.crearPublicacion(publicacion);
      console.log('Documento creado exitosamente:', documentoCreado);
      setSuccess(true);
      // Limpia el formulario después de una creación exitosa
      setPublicacion({
        nombre: '',
        descripcion: '',
        autores: [''],
        visibilidad: '',
        categorias: [''],
        fechaPublicacion: ''
      });
      // Cierra el modal después de un breve delay para mostrar el mensaje de éxito
      setTimeout(() => {
        closeModal();
      }, 2000);
    } catch (error) {
      console.error('Error al crear el documento:', error);
      setError('Hubo un error al crear el documento. Por favor, inténtalo de nuevo.');
    }
  };

  return (
    <div name="CrearDocumento" className={styles.crearDocumento}>
      <div className={styles.titleContainer}>
        <p>Crear una nueva <br />
          <b>Publicación</b>
        </p>
      </div>
      <button onClick={openModal} className={styles.openModalButton}>Crear nueva publicación</button>

      {isModalOpen && (
        <div className={`${styles.modalOverlay} ${isModalOpen ? styles.open : ''}`}>
          <div className={styles.modalContent}>
            <button onClick={closeModal} className={styles.closeModalButton}>X</button>
            
            <div className={styles.titleInsideContainer}>
              <p>Crear una nueva <br />
              <b>Publicación</b>
              </p>
            </div>

            {error && <p className={styles.errorMessage}>{error}</p>}
            {success && <p className={styles.successMessage}>Publicación creada exitosamente</p>}

            <form className={styles.form} onSubmit={handleSubmit}>
              <label htmlFor="nombre">Título de la Publicación:</label>
              <input
                id="titulo"
                name="nombre"
                value={publicacion.nombre}
                onChange={handleInputChange}
                required
                className={styles .input}
              />

              <label htmlFor="descripcion">Descripción de la Publicación:</label>
              <textarea
                id="descripcion"
                name="descripcion"
                value={publicacion.descripcion}
                onChange={handleInputChange}
                required
                className={styles.textarea}
              />

              <label>Autor(es):</label>
              {publicacion.autores.map((autor, index) => (
                <div key={index}>
                  <input
                    type="text"
                    value={autor}
                    onChange={(event) => handleAutoresChange(event, index)}
                    required
                    className={styles.input}
                  />
                </div>
              ))}
              <button type="button" onClick={() => setPublicacion({ ...publicacion, autores: [...publicacion.autores, ''] })}>
                Agregar autor
              </button>

              <label>Categorías:</label>
              {publicacion.categorias.map((categoria, index) => (
                <div key={index}>
                  <input
                    type="text"
                    value={categoria}
                    onChange={(event) => handleCategoriasChange(event, index)}
                    required
                    className={styles.input}
                  />
                </div>
              ))}
              <button type="button" onClick={() => setPublicacion({ ...publicacion, categorias: [...publicacion.categorias, ''] })}>
                Agregar categoría
              </button>

              <label>Visibilidad:</label>
              <select
                id="visibilidad"
                name="visibilidad"
                value={publicacion.visibilidad}
                onChange={handleInputChange}
                required
                className={styles.select}
              >
                <option value="">Seleccione una opción</option>
                <option value="publico">Público</option>
                <option value="privado">Privado</option>
              </select>

              <label>Fecha de Publicación:</label>
              <input
                id="fechaPublicacion"
                name="fechaPublicacion"
                value={publicacion.fechaPublicacion}
                onChange={handleInputChange}
                required
                type="date"
                className={styles.input}
              />

              <button type="submit" className={styles.submitButton}>Crear Publicación</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default CrearPublicacion;