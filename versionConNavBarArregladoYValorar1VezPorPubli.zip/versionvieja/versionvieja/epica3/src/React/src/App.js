import Home from "./Screens/Home";
import HowWeWork from "./Screens/HowWeWork";
import Benefits from "./Screens/Benefits";
import Contact from "./Screens/Contact";
import NavBar from "./Components/NavBar";
import Perfil from "./Components/Perfil";
import DocumentCatalog from "./Screens/DocumentCatalog";
import Login from "./Components/Login";
import Registro from "./Components/Registro";
import RecuperarContrasena from './Components/RecuperarContrasena';
import PublicationDetail from './Components/PublicationDetail'; // Importa el nuevo componente
import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import styles from './App.module.css';

function App() {

  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
  };
  
  return (
    <Router>
      <div className="App">
        <NavBar isAuthenticated={isAuthenticated} />
        <Routes>
          <Route path="/" element={
            <>
              <Home isAuthenticated={isAuthenticated} />
              <DocumentCatalog />
              <HowWeWork />
              <Benefits />
              <Contact />
            </>
          } />
          <Route path="/login" element={
            isAuthenticated ? <Navigate to="/perfil" /> : <Login onLogin={handleLogin} />
          } />
          <Route path="/recuperar" element={<RecuperarContrasena />} />
          <Route path="/registro" element={<Registro />} />
          <Route path="/perfil" element={
            isAuthenticated ? <Perfil onLogout={handleLogout} /> : <Navigate to="/login" />
          } />
          {/* Ruta de detalles de la publicación */}
          <Route path="/publicaciones/:id" element={<PublicationDetail />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
