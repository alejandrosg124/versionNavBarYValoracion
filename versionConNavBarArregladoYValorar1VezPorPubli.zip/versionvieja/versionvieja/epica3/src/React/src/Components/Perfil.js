import React,  { useState, useEffect }  from 'react';
import axios from 'axios';
import CrearDocumento from '../GestionDocumentos/CrearPublicacion';
import styles from './Perfil.module.css';
import EditarPublicacion from '../GestionDocumentos/EditarPublicacion';
import EliminarPublicacion from '../GestionDocumentos/EliminarPublicacion';

const Perfil = ({ onLogout, usuarioId }) => {

  const [datos, setDatos] = useState({
    nombre: '',
    email: '',
    nombreUsuario: '',
    preguntaSeguridad: '',
    respuestaSeguridad: '',
    fechaNacimiento: '',
    telefono: '',
    direccion: '',
    historialContraseñas: [],
  });

  const [modalActualizar, setModalActualizar] = useState(false);
  const [modalPreguntaSeguridad, setModalPreguntaSeguridad] = useState(false);
  const [nuevosDatos, setNuevosDatos] = useState({});
  const [mensajeExito, setMensajeExito] = useState('');
  const [modalConfirmacion, setModalConfirmacion] = useState(false); // Nuevo estado para el modal de confirmación


  useEffect(() => {
    const usuario = JSON.parse(localStorage.getItem('user'));
    if (usuario) {
      // Formatear la fecha de nacimiento si existe
      if (usuario.fechaNacimiento) {
        usuario.fechaNacimiento = new Date(usuario.fechaNacimiento).toLocaleDateString('es-ES');
      }
      setDatos({
        nombre: usuario.nombre || '',
        email: usuario.email || '',
        nombreUsuario: usuario.nombreUsuario || '',
        preguntaSeguridad: usuario.preguntaSeguridad || '',
        respuestaSeguridad: usuario.respuestaSeguridad || '',
        fechaNacimiento: usuario.fechaNacimiento || '',
        telefono: usuario.telefono || '',
        direccion: usuario.direccion || '',
      });
    }
  }, []);
  const actualizarDatos = () => {
    //  se hace la llamada a la API para actualizar los datos
     axios.put(`/api/usuarios/${datos._id}`, nuevosDatos)
      .then(response => {
        setDatos(response.data);
        setModalActualizar(false);
        mostrarMensajeExito('Datos actualizados con éxito.');
      })
      .catch(error => console.error('Error al actualizar datos:', error));
  };

  const eliminarCuenta = () => {
    // aca se hace la llamada a la API para eliminar la cuenta
    axios.delete(`/api/usuarios/${datos._id}`)
      .then(response => {
        if (response.status === 200) {
          onLogout(); 
          mostrarMensajeExito('Cuenta eliminada con éxito. Recibirás un a notificación al correo.');
        }
      })
      .catch(error => console.error('Error al eliminar cuenta:', error));
  };

  const confirmarEliminacion = () => {
    eliminarCuenta();
    setModalConfirmacion(false);
  };

  const cambiarPreguntaSeguridad = () => {
    // aca hace la llamada a la API para cambiar la pregunta de seguridad
    axios.put(`/api/usuarios/${datos._id}/preguntaSeguridad`, nuevosDatos)
      .then(response => {
        setDatos(response.data);
        setModalPreguntaSeguridad(false);
        mostrarMensajeExito('Pregunta de seguridad cambiada con éxito.');
      })
      .catch(error => console.error('Error al cambiar pregunta de seguridad:', error));
  };

  const mostrarMensajeExito = (mensaje) => {
    setMensajeExito(mensaje);
    setTimeout(() => {
      setMensajeExito('');
    }, 3000);
  };

  const abrirModalActualizar = () => {
    setNuevosDatos({
      nombre: datos.nombre,
      email: datos.email,
      nombre_usuario: datos.nombre_usuario,
      fechaNacimiento: datos.fechaNacimiento,
      numero: datos.numero,
      direccion: datos.direccion,
    });
    setModalActualizar(true);
  };

  const abrirModalPreguntaSeguridad = () => {
    setNuevosDatos({
      preguntaSeguridad: datos.preguntaSeguridad,
      respuestaSeguridad: datos.respuestaSeguridad,
    });
    setModalPreguntaSeguridad(true);
  };

  const abrirModalConfirmacion = () => {
    setModalConfirmacion(true);
  };

  return (
    <div className={styles.perfilContainer}>
      {mensajeExito && (
        <div className={styles.mensajeExito}>
          {mensajeExito}
        </div>
      )}
      <button className={styles.logoutButton} onClick={onLogout}>
        Cerrar Sesión
      </button>
      <h1 className={styles.title}>
        Perfil del <span className={styles.usuario}>Usuario</span>
      </h1>
      <p>Aquí puedes gestionar tu perfil y crear nuevos documentos.</p>
      <div className={styles.informacionUsuario}>
        <p><strong>Nombre:</strong> {datos.nombre}</p>
        <p><strong>Correo electrónico:</strong> {datos.email}</p>
        <p><strong>Nombre de Usuario:</strong> {datos.nombreUsuario}</p>
        <p><strong>Fecha de Nacimiento:</strong> {datos.fechaNacimiento}</p>
        <p><strong>telefono:</strong> {datos.telefono}</p> 
        <p><strong>Dirección:</strong> {datos.direccion}</p>
      </div>
      <div className={styles.accionesPerfil}>
        <button className={styles.actualizarDatosButton} onClick={() => setModalActualizar(true)}>
          Actualizar datos
        </button>
        <button className={styles.eliminarCuentaButton} onClick={eliminarCuenta}>
          Eliminar cuenta
        </button>
        <button className={styles.cambiarPreguntaSeguridadButton} onClick={() => setModalPreguntaSeguridad(true)}>
          Cambiar pregunta de seguridad
        </button>
      </div>

      {modalActualizar && (
        <div className={styles.modalActualizar}>
          <h2>Actualizar datos</h2>
          <form>
            <label>
                <p>Nombre:</p>
                <input type="text" value={nuevosDatos.nombre} onChange={(e) => setNuevosDatos({ ...nuevosDatos, nombre: e.target.value })} />
            </label>
            <label>
                <p>Correo:</p>
                <input type="email" value={nuevosDatos.email} onChange={(e) => setNuevosDatos({ ...nuevosDatos, email: e.target.value })} />
            </label>
            <label>
                <p>Nombre de usuario:</p>
                <input type="text" value={nuevosDatos.nombre_usuario} onChange={(e) => setNuevosDatos({ ...nuevosDatos, nombre_usuario: e.target.value })} />
            </label>
            <label>
                <p>Fecha de nacimiento:</p>
                <input type="date" value={nuevosDatos.fechaNacimiento} onChange={(e) => setNuevosDatos({ ...nuevosDatos, fechaNacimiento: e.target.value })} />
            </label>
            <label>
                <p>Número:</p>
                <input type="tel" value={nuevosDatos.numero} onChange={(e) => setNuevosDatos({ ...nuevosDatos, numero: e.target.value })} />
            </label>
            <label>
                <p>Dirección:</p>
                <input type="text" value={nuevosDatos.direccion} onChange={(e) => setNuevosDatos({ ...nuevosDatos, direccion: e.target.value })} />
            </label>
            <button onClick={actualizarDatos}>Actualizar</button>
          </form>
        </div>
      )}

      {modalPreguntaSeguridad && (
        <div className={styles.modalPreguntaSeguridad}>
          <h2>Cambiar pregunta de seguridad</h2>
          <form>
            <label>
              <p>Pregunta de seguridad:</p>
              <input
                type="text"
                value={nuevosDatos.preguntaSeguridad}
                onChange={(e) => setNuevosDatos({ ...nuevosDatos, preguntaSeguridad: e.target.value })}
                placeholder="Pregunta de seguridad"
              />
            </label>
            <label>
              <p>Respuesta de seguridad:</p>
              <input
                type="text"
                value={nuevosDatos.respuestaSeguridad}
                onChange={(e) => setNuevosDatos({ ...nuevosDatos, respuestaSeguridad: e.target.value })}
                placeholder="Respuesta de seguridad"
              />
            </label>
            <button onClick={cambiarPreguntaSeguridad}>
              Cambiar
            </button>
            <button onClick={() => setModalPreguntaSeguridad(false)}>
              Cancelar
            </button>
          </form>
        </div>
      )}  

      {modalConfirmacion && (
        <div className={styles.modalConfirmacion}>
          <h2>Eliminar cuenta</h2>
          <p>¿Estás seguro de que deseas eliminar tu cuenta?</p>
          <button onClick={confirmarEliminacion}>Confirmar</button>
          <button onClick={() => setModalConfirmacion(false)}>Cancelar</button>
        </div>
      )}
      
      <CrearDocumento />
      <EditarPublicacion />
      <EliminarPublicacion />
    </div>
  );
};

export default Perfil;