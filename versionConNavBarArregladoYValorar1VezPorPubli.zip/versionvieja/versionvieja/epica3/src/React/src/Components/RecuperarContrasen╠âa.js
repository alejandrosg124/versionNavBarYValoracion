import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './RecuperarContraseña.module.css';

const RecuperarContraseña = () => {
    const [email, setEmail] = useState('');
    const [securityQuestion, setSecurityQuestion] = useState('');
    const [securityAnswer, setSecurityAnswer] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [errorMessage, setErrorMessage] = useState('');
    const [successMessage, setSuccessMessage] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();

        // Aquí debes incluir la lógica para verificar la respuesta de seguridad y cambiar la contraseña.
        if (newPassword !== confirmPassword) {
            setErrorMessage('Las contraseñas no coinciden.');
            return;
        }

        try {
            const response = await fetch('http://localhost:8080/api/auth/recuperar', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ email, securityAnswer, newPassword })
            });

            if (response.ok) {
                setSuccessMessage('Contraseña actualizada correctamente.');
                navigate('/login'); // Redirigir a la página de inicio de sesión
            } else {
                const errorText = await response.text();
                setErrorMessage(errorText);
            }
        } catch (error) {
            console.error('Error de red:', error);
            setErrorMessage('Error de red, por favor intenta de nuevo.');
        }
    };

    return (
        <div className="wrapper">
            <h2>Recuperar Contraseña</h2>
            {errorMessage && <div className="error-message">{errorMessage}</div>}
            {successMessage && <div className="success-message">{successMessage}</div>}
            <form onSubmit={handleSubmit}>
                <div className="input-field">
                    <input 
                        type="email" 
                        required 
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                    <label>Ingresa tu correo electrónico</label>
                </div>
                <div className="input-field">
                    <input 
                        type="text" 
                        required 
                        value={securityQuestion} 
                        readOnly 
                    />
                    <label>Pregunta de seguridad</label>
                </div>
                <div className="input-field">
                    <input 
                        type="text" 
                        required 
                        value={securityAnswer}
                        onChange={(e) => setSecurityAnswer(e.target.value)}
                    />
                    <label>Respuesta de seguridad</label>
                </div>
                <div className="input-field">
                    <input 
                        type="password" 
                        required 
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                    />
                    <label>Nueva contraseña</label>
                </div>
                <div className="input-field">
                    <input 
                        type="password" 
                        required 
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                    />
                    <label>Confirma nueva contraseña</label>
                </div>
                <button type="submit">Actualizar Contraseña</button>
            </form>
        </div>
    );
};

export default RecuperarContraseña;
