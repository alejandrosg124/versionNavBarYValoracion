import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import styles from './PublicationDetail.module.css';
import { faStar as filledStar } from '@fortawesome/free-solid-svg-icons';
import { faStar as emptyStar } from '@fortawesome/free-regular-svg-icons';
import axios from 'axios';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

const PublicationDetail = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [publication, setPublication] = useState(null);
    const [comments, setComments] = useState([]);
    const [newComment, setNewComment] = useState("");
    const [user, setUser] = useState(null);
    const [editCommentId, setEditCommentId] = useState(null);
    const [editContent, setEditContent] = useState("");
    const [averageRating, setAverageRating] = useState(0);
    const [userRating, setUserRating] = useState(0);
    const [hasRated, setHasRated] = useState(false);
    const [successMessage, setSuccessMessage] = useState("");

    useEffect(() => {
        const loggedUser = JSON.parse(localStorage.getItem('user'));
        if (loggedUser) {
            setUser(loggedUser);
        } else {
            setUser(null);
        }

        const fetchData = async () => {
            try {
                const pubResponse = await fetch(`http://localhost:8080/publicaciones/detalles/${id}`);
                const pubData = await pubResponse.json();
                setPublication(pubData);

                if (pubData.valoraciones && pubData.valoraciones.length > 0) {
                    calculateAverageRating(pubData.valoraciones);
                }

                const commentsResponse = await fetch(`http://localhost:8080/publicaciones/${id}/comentarios`);
                const commentsData = await commentsResponse.json();
                setComments(commentsData);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        fetchData();
    }, [id]);

    const handleCommentChange = (event) => {
        setNewComment(event.target.value);
    };

    const handleCommentSubmit = async (event) => {
        event.preventDefault();

        if (!user) {
            alert("Debes iniciar sesión para comentar.");
            navigate('/login');
            return;
        }

        const commentData = {
            usuarioId: user.nombreUsuario,
            contenido: newComment,
        };

        try {
            const response = await fetch(`http://localhost:8080/publicaciones/${id}/comentarios`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(commentData),
            });

            if (response.ok) {
                setComments([...comments, { ...commentData, fechaCreacion: new Date().toISOString(), id: new Date().getTime() }]);
                setNewComment("");
            } else {
                console.error("Error posting comment");
            }
        } catch (error) {
            console.error('Error posting comment:', error);
        }
    };

    const handleEditComment = (commentId, content) => {
        setEditCommentId(commentId);
        setEditContent(content);
    };

    const handleEditSubmit = async (event) => {
        event.preventDefault();

        if (!user) {
            alert("Debes iniciar sesión para editar comentarios.");
            navigate('/login');
            return;
        }

        try {
            const response = await fetch(
                `http://localhost:8080/publicaciones/${id}/comentarios?usuarioId=${user.nombreUsuario}&nuevoContenido=${editContent}`,
                {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                }
            );

            if (response.ok) {
                setComments(comments.map(comment =>
                    comment.id === editCommentId ? { ...comment, contenido: editContent } : comment
                ));
                setEditCommentId(null);
                setEditContent("");
            } else {
                console.error("Error editing comment");
            }
        } catch (error) {
            console.error('Error editing comment:', error);
        }
    };

    const handleDeleteComment = async (commentId) => {
        try {
            const response = await fetch(`http://localhost:8080/publicaciones/${id}/comentarios/${commentId}`, {
                method: 'DELETE',
            });

            if (response.ok) {
                setComments(comments.filter(comment => comment.id !== commentId));
            } else {
                console.error("Error deleting comment");
            }
        } catch (error) {
            console.error('Error deleting comment:', error);
        }
    };

    if (!publication) {
        return <div>Loading...</div>;
    }

    const calculateAverageRating = (valoraciones) => {
        const total = valoraciones.reduce((acc, val) => acc + val.puntuacion, 0);
        setAverageRating((total / valoraciones.length).toFixed(1));
    };

    const handleRating = async (rating) => {
    if (!user) {
        alert("Debes estar registrado para poder valorar.");
        navigate('/login');
        return;
    }

    if (hasRated) return; // si ya valoró el usuario.

    try {
        await axios.post(`http://localhost:8080/publicaciones/${id}/calificar`, {
            puntuacion: rating,
            usuarioId: user.id 
        });
        setUserRating(rating);
        setHasRated(true);
        setSuccessMessage("¡Gracias por valorar, cada vez nos ayudas a mejorar más! ;)");

        setAverageRating(((averageRating * publication.valoraciones.length + rating) / (publication.valoraciones.length + 1)).toFixed(1));
        
        setTimeout(() => {
            setSuccessMessage("");
        }, 3000);

    } catch (error) {
        console.error('Ocurrió un error al valorar la publicación.', error);
    }
    };

    return (
        <div className={styles.publicationDetail}>
            <h1>{publication.titulo}</h1>
            <p><strong>Descripción:</strong> {publication.descripcion}</p>
            <p><strong>Fecha de publicación:</strong> {new Date(publication.fechaPublicacion).toLocaleDateString()}</p>
            <p><strong>Visibilidad:</strong> {publication.visibilidad}</p>
            <p><strong>Autores:</strong> {publication.autores.map(autor => autor.nombre).join(', ')}</p>

            <div className={styles.ratingSection}>
                <h3>Valoración promedio: {averageRating} estrellas</h3>
                {user ? (
                    <div className={styles.stars}>
                        {[...Array(5)].map((_, index) => (
                            <FontAwesomeIcon
                                key={index}
                                icon={index < userRating ? filledStar : emptyStar}
                                onClick={() => handleRating(index + 1)}
                                className={styles.starIcon}
                                style={{ color: index < averageRating ? "gold" : "grey", cursor: hasRated ? "default" : "pointer" }}
                            />
                        ))}
                    </div>
                ) : (
                    <p>Debes estar registrado para poder valorar.</p>
                )}
                {successMessage && <p className={styles.successMessage}>{successMessage}</p>}
            </div>

            <h2>Vista completa del PDF:</h2>
            {publication.archivoBase64 ? (
                <iframe
                    src={`data:application/pdf;base64,${publication.archivoBase64}`}
                    title="Vista del PDF"
                    width="100%"
                    height="500px"
                />
            ) : (
                <p>No se encontró el archivo PDF para esta publicación.</p>
            )}

            <h2>Comentarios</h2>
            <div className={styles.commentsSection}>
                {comments.length > 0 ? (
                    comments.map((comment) => (
                        <div key={comment.id} className={styles.comment}>
                            <p><strong>Usuario:</strong> {comment.usuarioId}</p>
                            <p>{comment.contenido}</p>
                            <p><em>Fecha:</em> {new Date(comment.fechaCreacion).toLocaleDateString()}</p>
                            {user && user.nombreUsuario === comment.usuarioId && (
                                <div>
                                    <button onClick={() => handleEditComment(comment.id, comment.contenido)}>Editar</button>
                                    <button onClick={() => handleDeleteComment(comment.id)}>Eliminar</button>
                                </div>
                            )}
                        </div>
                    ))
                ) : (
                    <p>No hay comentarios aún.</p>
                )}
            </div>

            {user ? (
                editCommentId ? (
                    <form onSubmit={handleEditSubmit} className={styles.commentForm}>
                        <textarea
                            value={editContent}
                            onChange={(e) => setEditContent(e.target.value)}
                            maxLength="230"
                            required
                        />
                        <button type="submit">Guardar cambios</button>
                    </form>
                ) : (
                    <form onSubmit={handleCommentSubmit} className={styles.commentForm}>
                        <textarea
                            value={newComment}
                            onChange={handleCommentChange}
                            placeholder="Escribe tu comentario aquí..."
                            maxLength="230"
                            required
                        />
                        <button type="submit">Enviar comentario</button>
                    </form>
                )
            ) : (
                <p>Inicia sesión para poder comentar.</p>
            )}
        </div>
    );
};

export default PublicationDetail;
